dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.zh.common"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.zh.common");dojo._xdLoadFlattenedBundle("dijit", "common", "zh", {"buttonOk":"确定","buttonCancel":"取消","buttonSave":"保存","itemClose":"关闭"});
}};});